class Category < ApplicationRecord
  has_many :ideas
end
